#include "copy_turtle/cpp_header.hpp"

#include <iostream>

int main() {
    std::cout << "Hello World!\n";
    return 0;
}
